SOT23-6_Adapter by dotechin on Thingiverse: https://www.thingiverse.com/thing:3642573

Summary:
There is quite few information for using SOT23-6 Packages, Such as ATtiny10 MCU and so on.Therefore I made design for this Adapter.You can use this STL model,or you can modify.If you improove someting, Please upload this Thingiverse site,Please.